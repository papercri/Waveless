
export interface User {
  id: number
  name: string
  email: string
  status: 'activo' | 'inactivo'
}
